# -*- coding: utf-8 -*-
"""
Created on Fri Feb 24 16:17:53 2023

@author: Zhengke Liu
"""

import pandas as pd
from math import radians, cos, sin, asin, sqrt
import os
from joblib import Parallel, delayed

def haversine(lon1, lat1, lon2, lat2):
    """
    Calculate the great circle distance between two points 
    on the earth (specified in decimal degrees)
    """
    # Convert decimal degrees to radians
    lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2])
 
    # Haversine formula
    dlon = lon2 - lon1 
    dlat = lat2 - lat1 
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * asin(sqrt(a)) 
    r = 6371.393 # Average radius of Earth in kilometers
    return c * r * 1000

cur_dir = os.path.dirname(os.path.abspath(__file__))  # Path of the current file's directory

'''Create a folder named Merge_stable_point in the current path'''

print(cur_dir)
path_list = os.listdir(cur_dir, )
path_list.remove("vehicle_cal.py")

path_list.remove("bus_2_line_depot.xlsx")
path_list.remove("depot_location.csv")
path_list.remove("Merge_stable_point")

# output_path = cur_dir + "/Merge_stable_point/"
output_path = "D:/process_GPS_code" + "/Merge_stable_point/"

def processing_df(excel):
    raw_data = pd.read_excel(excel)
    raw_data = raw_data.fillna(0)
    
    raw_data['speed'] = raw_data['speed'].astype(float)

    raw_data['gps_time'] = raw_data['gps_time'].astype(str)
    raw_data['day'] = raw_data['gps_time'].str[:8].astype(int)
    
    
    day = 20201019
    new_data = raw_data[raw_data['day'] == day]
    
    # Filter invalid data
    if (len(new_data) <= 30 or (sum(new_data["speed"]) == 0)):
        return 0
    
    new_data['gps_time'] = new_data['gps_time'].str[-6:] 
    new_data.sort_values(by = "gps_time", ascending = True, inplace = True)
    new_data.reset_index(inplace = True, drop = True)
    
    ########################################################### Trajectory correction ##########################################################
    W1_index = [0] 
    W2_index = [] 
    
    max_speed = min(30, max(new_data["speed"]))
    
    flag = 1
    
    """flag = 1: GPS point on the trajectory
       flag = -1: GPS point offset trajectory"""
    
    second_list = [3600 * int(new_data["gps_time"][0][0:2]) + 60 * int(new_data["gps_time"][0][2:4]) + int(new_data["gps_time"][0][4:6])]
    
    for i in range(1, len(new_data)):
        second_list.append(3600 * int(new_data["gps_time"][i][0:2]) + 60 * int(new_data["gps_time"][i][2:4]) + int(new_data["gps_time"][i][4:6]))
        
        # Calculate the time interval and distance between adjacent GPS points
        time_interval = second_list[i] - second_list[i - 1]
        space_interval = haversine(new_data["longitude"][i], new_data["latitude"][i], new_data["longitude"][i - 1], new_data["latitude"][i - 1])
        
        if (flag == 1):
            if (space_interval == 0):
                W1_index.append(i)
            
            # Distance anomaly or speed anomaly
            elif (space_interval > 10000 or space_interval/time_interval > max_speed):
                flag = flag * -1 # GPS point offset trajectory
                W2_index.append(i)
                
            else:
                W1_index.append(i)
        
        else:
            if (space_interval == 0):
                W2_index.append(i)
                if (len(W2_index) >= 5):
                    if (len(W1_index) >= 3):
                        W1_index += W2_index
                        W2_index = []
                    else:
                        W1_index = W2_index.copy()
                        W2_index = []
                    flag = flag * -1 # GPS point back to the trajectory
            
            elif (space_interval > 10000 or space_interval/time_interval > max_speed):
                W2_index = [i]

            else:
                W2_index.append(i)
                if (len(W2_index) >= 5):
                    if (len(W1_index) >= 3):
                        W1_index += W2_index
                        W2_index = []
                    else:
                        W1_index = W2_index.copy()
                        W2_index = []
                    flag = flag * -1
    
    new_data["second"] = second_list   
    new_data = new_data[new_data.index.isin(W1_index)]
    new_data.reset_index(drop = True, inplace = True)
    
    # Calculate the time interval and distance between adjacent GPS points
    time_interval_list = [-1]
    space_interval_list = [-1]
    for i in range(1, len(new_data)):
        if (new_data["speed"][i - 1] == 0 and new_data["line_name"][i - 1] == 0 and new_data["speed"][i] == 0 and new_data["line_name"][i] == 0):
            new_data["longitude"][i] = new_data["longitude"][i - 1]
            new_data["latitude"][i] = new_data["latitude"][i - 1]
            time_interval = new_data["second"][i] - new_data["second"][i - 1]
            time_interval_list.append(time_interval)
            space_interval_list.append(0)

        else:
            time_interval = new_data["second"][i] - new_data["second"][i - 1]
            space_interval = haversine(new_data["longitude"][i], new_data["latitude"][i], new_data["longitude"][i - 1], new_data["latitude"][i - 1])
            time_interval_list.append(time_interval)
            space_interval_list.append(space_interval)

    new_data["time_interval"] = time_interval_list
    new_data["spacing"] = space_interval_list
    
    # Filter invalid data
    if (sum(space_interval_list) < 5000):
        return 0
    
    ############################################## Vehicle stop point identification and merging ##############################################
    check_point = []
    flag = 1
    """flag = 1: vehicle moving state
       flag = -1: vehicle stopping state"""
    
    for i in range(len(new_data) - 1):
        if (new_data["spacing"][i] != 0 and new_data["spacing"][i + 1] == 0):
            check_point.append(2) # vehicle start stopping
            flag = -1 * flag
        elif (new_data["spacing"][i] == 0 and new_data["spacing"][i + 1] != 0):
            check_point.append(3) # vehicle end stopping
            flag = -1 * flag
        else:
            check_point.append(flag)
    
    """check_point_state 1: vehicle is moving
       check_point_state 2: vehicle starts stopping
       check_point_state 3: vehicle ends stopping"""
       
    if (new_data["spacing"][len(new_data) - 1] == 0 or new_data["speed"][len(new_data) - 1] == 0):
        check_point.append(3)
    else:
        check_point.append(1)
     
    new_data["stop_label"] = check_point
    
    # Vehicle stop point merging
    new_data = new_data[new_data["stop_label"] != -1]
    new_data.reset_index(inplace = True, drop = True)

    ############################################## mark out bus stops at bus depots ##############################################
    depot_list = []
    line_name_list = []

    depot_duration_list = []
    
    depot_label_list = [0]
    start_time_list = [-1 for i in range(len(new_data))]
    end_time_list = [-1 for i in range(len(new_data))]
        
    for i in range(1, len(new_data) - 1):
        new_data["time_interval"][i] = new_data["second"][i] - new_data["second"][i - 1]
        """When the bus stops at the same location for more than 15 minutes,
            it is considered to have stopped at the bus depot"""
        if (new_data["time_interval"][i] > 900): 
            if (new_data["stop_label"][i] == 3):
                """depot_label_1: bus at depots
                   depot_lavewl_0: otherwise"""
                depot_label_list.append(1)
                depot_list.append([new_data["longitude"][i - 1], new_data["latitude"][i - 1]])
                depot_duration_list.append(new_data["time_interval"][i])
                
                start_time_list[i] = new_data["second"][i - 1]
                end_time_list[i] = new_data["second"][i]
                
            else:
                depot_label_list.append(0)
                
        else:
            depot_label_list.append(0)
    
    # the final GPS point
    i += 1
    over_day_time = 86400 - new_data["second"][i] + new_data["second"][0]
    if (over_day_time > 900):
        new_data["time_interval"][i] = over_day_time
        depot_label_list.append(1)
        depot_list.append([new_data["longitude"][i], new_data["latitude"][i]])
        depot_duration_list.append(new_data["time_interval"][i])
        start_time_list[i] = new_data["second"][i]
        end_time_list[i] = new_data["second"][0]
      
    else:
        new_data["time_interval"][i] = new_data["second"][i] - new_data["second"][i - 1]
        depot_label_list.append(0)
        
    new_data["depot_label"] = depot_label_list
    new_data["depot_start_time"] = start_time_list
    new_data["depot_end_time"] = end_time_list
    
    ################## Find out the longest period of time when the bus stops at the depot ##################
    maximum_depot_duraion_index = -1
    maximum_depot_duration = 0
    for duration_index in range(len(depot_duration_list)):
        if depot_duration_list[duration_index] > maximum_depot_duration:
            
            maximum_depot_duraion_index = duration_index
          
    line_name_list.append(list(set(new_data["line_name"].tolist())))
    new_data.to_excel(output_path + excel, index = False)
    
    return excel[:-4], line_name_list, depot_list, maximum_depot_duraion_index

# parallel processing
total_list = Parallel(n_jobs = 16)(delayed(processing_df)(excel) for excel in path_list)


vehicle_list = []
use_label_list = []
bus_2_depot_list = []
bus_2_line_list = []
maximum_depot_duraion_id_list = []

for i in range(len(total_list)):
    if (total_list[i] == 0):
        vehicle_list.append(0)
        bus_2_line_list.append(0)
        bus_2_depot_list.append(0)
        maximum_depot_duraion_id_list.append(-1)
        use_label_list.append(0)
    else:
        vehicle_list.append(total_list[i][0])
        line_name = total_list[i][1][0]
        bus_2_depot_list.append(total_list[i][2])
        maximum_depot_duraion_id_list.append(total_list[i][3])
        use_label_list.append(1)
        
        if 0 in line_name:
            line_name.remove(0)
        bus_2_line_list.append(line_name)

bus_2_line_depot_df = pd.DataFrame()
bus_2_line_depot_df["bus_id"] = vehicle_list
bus_2_line_depot_df["bus_2_line"] =  bus_2_line_list
bus_2_line_depot_df["bus_2_depot"] = bus_2_depot_list
bus_2_line_depot_df["maximum_depot_duraion_index"] = maximum_depot_duraion_id_list
bus_2_line_depot_df["use_label"] = use_label_list

useful_df = bus_2_line_depot_df[bus_2_line_depot_df["use_label"] == 1]
useful_df.reset_index(inplace = True, drop = True)

index = 0
x_total_list = []
y_total_list = []
maximum_duration_label = []

depot_start_index_list = []
depot_end_index_list = []

for i in range(len(useful_df)):
    temp_list = useful_df["bus_2_depot"][i]
    maximum_duration_index = useful_df["maximum_depot_duraion_index"][i]
    
    depot_start_index_list.append(index)
    
    for point_index in range(len(temp_list)):
        index += 1
        x_total_list.append(temp_list[point_index][0])
        y_total_list.append(temp_list[point_index][1])
        if (point_index == maximum_duration_index):
            maximum_duration_label.append(1)
        else:
            maximum_duration_label.append(0)
            
    depot_end_index_list.append(index)    

useful_df["depot_start_index"] = depot_start_index_list
useful_df["depot_end_index"] = depot_end_index_list
useful_df.to_excel("bus_2_line_depot.xlsx", index = False)

depot_df = pd.DataFrame()
depot_df["id"] = [i for i in range(len(x_total_list))]
depot_df["x"] = x_total_list
depot_df["y"] = y_total_list 
depot_df["maximum_duration_label"] = maximum_duration_label
depot_df.to_excel("depot_location.xlsx", index = False)   

